/*
 * This file is @generated automatically.
 * Do not modify anything in here by hand.
 *
 * Created from $FreeBSD$
 */


struct vop_vector {
	struct vop_vector	*vop_default;
	vop_bypass_t	*vop_bypass;
	vop_islocked_t	*vop_islocked;
	vop_lookup_t	*vop_lookup;
	vop_cachedlookup_t	*vop_cachedlookup;
	vop_create_t	*vop_create;
	vop_whiteout_t	*vop_whiteout;
	vop_mknod_t	*vop_mknod;
	vop_open_t	*vop_open;
	vop_close_t	*vop_close;
	vop_fplookup_vexec_t	*vop_fplookup_vexec;
	vop_fplookup_symlink_t	*vop_fplookup_symlink;
	vop_access_t	*vop_access;
	vop_accessx_t	*vop_accessx;
	vop_stat_t	*vop_stat;
	vop_getattr_t	*vop_getattr;
	vop_setattr_t	*vop_setattr;
	vop_mmapped_t	*vop_mmapped;
	vop_read_t	*vop_read;
	vop_read_pgcache_t	*vop_read_pgcache;
	vop_write_t	*vop_write;
	vop_ioctl_t	*vop_ioctl;
	vop_poll_t	*vop_poll;
	vop_kqfilter_t	*vop_kqfilter;
	vop_revoke_t	*vop_revoke;
	vop_fsync_t	*vop_fsync;
	vop_remove_t	*vop_remove;
	vop_link_t	*vop_link;
	vop_rename_t	*vop_rename;
	vop_mkdir_t	*vop_mkdir;
	vop_rmdir_t	*vop_rmdir;
	vop_symlink_t	*vop_symlink;
	vop_readdir_t	*vop_readdir;
	vop_readlink_t	*vop_readlink;
	vop_inactive_t	*vop_inactive;
	vop_need_inactive_t	*vop_need_inactive;
	vop_reclaim_t	*vop_reclaim;
	vop_lock1_t	*vop_lock1;
	vop_unlock_t	*vop_unlock;
	vop_bmap_t	*vop_bmap;
	vop_strategy_t	*vop_strategy;
	vop_getwritemount_t	*vop_getwritemount;
	vop_getlowvnode_t	*vop_getlowvnode;
	vop_print_t	*vop_print;
	vop_pathconf_t	*vop_pathconf;
	vop_advlock_t	*vop_advlock;
	vop_advlockasync_t	*vop_advlockasync;
	vop_advlockpurge_t	*vop_advlockpurge;
	vop_reallocblks_t	*vop_reallocblks;
	vop_getpages_t	*vop_getpages;
	vop_getpages_async_t	*vop_getpages_async;
	vop_putpages_t	*vop_putpages;
	vop_getacl_t	*vop_getacl;
	vop_setacl_t	*vop_setacl;
	vop_aclcheck_t	*vop_aclcheck;
	vop_closeextattr_t	*vop_closeextattr;
	vop_getextattr_t	*vop_getextattr;
	vop_listextattr_t	*vop_listextattr;
	vop_openextattr_t	*vop_openextattr;
	vop_deleteextattr_t	*vop_deleteextattr;
	vop_setextattr_t	*vop_setextattr;
	vop_setlabel_t	*vop_setlabel;
	vop_vptofh_t	*vop_vptofh;
	vop_vptocnp_t	*vop_vptocnp;
	vop_allocate_t	*vop_allocate;
	vop_advise_t	*vop_advise;
	vop_unp_bind_t	*vop_unp_bind;
	vop_unp_connect_t	*vop_unp_connect;
	vop_unp_detach_t	*vop_unp_detach;
	vop_is_text_t	*vop_is_text;
	vop_set_text_t	*vop_set_text;
	vop_unset_text_t	*vop_unset_text;
	vop_add_writecount_t	*vop_add_writecount;
	vop_fdatasync_t	*vop_fdatasync;
	vop_copy_file_range_t	*vop_copy_file_range;
	vop_vput_pair_t	*vop_vput_pair;
	vop_deallocate_t	*vop_deallocate;
	vop_inotify_t	*vop_inotify;
	vop_inotify_add_watch_t	*vop_inotify_add_watch;
	vop_spare1_t	*vop_spare1;
	vop_spare2_t	*vop_spare2;
	vop_spare3_t	*vop_spare3;
	vop_spare4_t	*vop_spare4;
	vop_spare5_t	*vop_spare5;
	bool	registered;
};
