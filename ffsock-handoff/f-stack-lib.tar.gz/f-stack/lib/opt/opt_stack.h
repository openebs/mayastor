//#define STACK    1
